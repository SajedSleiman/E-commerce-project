const CartItems = document.querySelector(".cart-items");
const cartTotalElement = document.getElementById("cart-total");
const checkoutBtn = document.getElementById("checkout-btn");

let cartTotal = 0;

function updateCartTotal() {
  const items = JSON.parse(localStorage.getItem("cart")) || [];
  cartTotal = items.reduce((total, item) => total + parseFloat(item.price), 0);
  cartTotalElement.textContent = cartTotal.toFixed(2);
}

function removeCartItem(id) {
  let items = JSON.parse(localStorage.getItem("cart")) || [];
  items = items.filter(item => item.id !== id);
  localStorage.setItem("cart", JSON.stringify(items));
  displayCartItems();
  updateCartTotal();
}

function displayCartItems() {
  CartItems.innerHTML = "";
  const items = JSON.parse(localStorage.getItem("cart")) || [];
  items.forEach((item) => {
    const cartItem = document.createElement("div");
    cartItem.className = "cart_item";
    cartItem.innerHTML = `
      <p class="cart_id">${item.id}</p>
      <p class="cart_title">${item.title}</p>
      <img src="${item.image}" alt="${item.title}" class="cart_img" />
      <p class="cart_price">${item.price}</p>
      <button class="cart_delete" data-id="${item.id}">Delete</button>
    `;
    CartItems.appendChild(cartItem);
  });

  // Add event listeners to delete buttons
  document.querySelectorAll(".cart_delete").forEach(button => {
    button.addEventListener("click", () => {
      const id = button.getAttribute("data-id");
      removeCartItem(id);
    });
  });

  updateCartTotal();
}

displayCartItems();
