var countDownDate = new Date("May 30, 2024 00:00:00").getTime();

    
    var x = setInterval(function () {

      var now = new Date().getTime();

      var distance = countDownDate - now;

      
      var days = Math.floor(distance / (1000 * 60 * 60 * 24));
      var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);

      
      document.getElementById("demo").innerHTML =
        days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

      
      if (distance < 0) {
        clearInterval(x);
        document.getElementById("demo").innerHTML = "EXPIRED";
      }
    }, 1000);

    var swiper = new Swiper(".mySwiper", {
      slidesPerView: 2,
      spaceBetween: 10,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      breakpoints: {
        640: {
          slidesPerView: 2,
          spaceBetween: 10,
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 10,
        },
        1024: {
          slidesPerView: 4,
          spaceBetween: 10,
        },
      },
    });

ScrollReveal().reveal(".top_nav", {
  origin: "bottom",
  distance: "20px",
  opacity: 0,
});
ScrollReveal().reveal(".nav", {
  origin: "bottom",
  distance: "20px",
  opacity: 0,
  delay: 100,
});

ScrollReveal().reveal(".header", {
  origin: "bottom",
  distance: "20px",
  opacity: 0,
  delay: 200,
});
ScrollReveal().reveal(".section", {
  origin: "bottom",
  distance: "20px",
  opacity: 0,
  duration: 1000,
  delay: 100,
});
ScrollReveal().reveal(".footer", {
  origin: "bottom",
  distance: "20px",
  opacity: 0,
  duration: 1000,
  delay: 100,
});


const hamburger = document.querySelector(".hamburger");
const Nav = document.querySelector(".mobile_nav");

hamburger.addEventListener("click", () => {
  Nav.classList.toggle("mobile_nav_hide");
});

const AddToCart = document.querySelectorAll(".add_to_cart");

AddToCart.forEach((button) => {
  button.addEventListener("click", () => {
    const id = button.getAttribute("data-id");
    const title = button.getAttribute("data-title");
    const image = button.getAttribute("data-image");
    const price = button.getAttribute("data-price");

    const cartItem = { id, title, image, price };
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(cartItem);
    localStorage.setItem("cart", JSON.stringify(cart));

    displayCartItems();
    updateCartTotal();
  });
});

checkoutBtn.addEventListener("click", () => {
  window.location.href = "./checkout.html";
});

function addProduct() {
  var input = document.getElementById('pic');
  var pic = input.files[0];
  var price = parseFloat(document.getElementById("price").value);
  var name = document.getElementById("name").value;

  if (pic) {
    var reader = new FileReader();
    reader.onload = function (e) {
      var row = document.createElement("tr");
      var pName = document.createElement("td");
      var pPrice = document.createElement("td");
      var pPhoto = document.createElement("td");
      var pDelete = document.createElement("td");

      pName.textContent = name;
      pPrice.textContent = price.toFixed(2);
      var img = document.createElement("img");
      img.src = e.target.result;
      img.alt = name + " photo";
      img.className = "product-image";
      pPhoto.appendChild(img);

      var deleteButton = document.createElement("button");
      deleteButton.textContent = "Delete";
      deleteButton.className = "delete-button";
      deleteButton.onclick = function () {
        row.remove();
      };
      pDelete.appendChild(deleteButton);

      row.appendChild(pName);
      row.appendChild(pPrice);
      row.appendChild(pPhoto);
      row.appendChild(pDelete);
      document.querySelector("#table tbody").appendChild(row);
    };
    reader.readAsDataURL(pic);
  }
}

function checkAdmin() {
  var email = document.getElementById('email').value;
  var password = document.getElementById('password').value;

  
  if (email === 'admin@example.com' && password === 'adminpassword') {
    window.location.href = 'admin.html';
  } else {
    
    document.getElementById('authForm').submit();
  }
}
