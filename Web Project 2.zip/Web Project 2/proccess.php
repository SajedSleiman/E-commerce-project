<?php
// Establish connection
$con = mysqli_connect("localhost", "root", "", "signup");

// Check connection
if (mysqli_connect_errno()) {
    die("Failed connectivity: " . mysqli_connect_error());
}

// Get form data
$username = $_POST['username'];
$password = $_POST['password'];
$test = false;

// Debug: Check if data is received
error_log("Username: $username, Password: $password");

// Check for admin credentials
if ($username === 'admin@gmail.com') {
    if ($password === 'admin12') {
        echo "<script>alert('Login successful!.'); window.location.href = 'Admin.php';</script>";
        exit();
    } else {
        echo "<script>alert('Authorized Access only!'); window.location.href = 'login.php';</script>";
        exit();
    }
}

// Prepare SQL statement
$stmt = $con->prepare("SELECT username, password FROM users WHERE username = ?");
if ($stmt === false) {
    die("Failed to prepare statement: " . htmlspecialchars($con->error));
}

// Bind parameters and execute statement
$stmt->bind_param("s", $username);
if (!$stmt->execute()) {
    die("Failed to execute statement: " . htmlspecialchars($stmt->error));
}

// Get result
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Verify the password (assuming it's stored in plain text, which is not recommended)
    if ($password == $row['password']) {
        $test = true;
    }
}

// Close statement and connection
$stmt->close();
$con->close();

// Debug: Check test result
error_log("Login success: " . ($test ? "Yes" : "No"));

// Redirect based on the result
if ($test) {
    echo "<script>alert('Login successful!.'); window.location.href = 'product.html';</script>";
} else {
    echo "<script>alert('Login failed!'); window.location.href = 'login.php';</script>";
    exit();
}
?>
