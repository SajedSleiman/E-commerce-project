<?php
// Establish connection
$con = mysqli_connect("localhost", "root", "", "signup");

// Check connection
if (mysqli_connect_errno()) {
    die("Failed connectivity: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the user already exists
    $checkStmt = $con->prepare("SELECT username FROM users WHERE username = ?");
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        // User already exists
        echo "<script>alert('User already exists. Please use a different email.'); window.location.href = 'sign-up.php';</script>";
    } else {
        // Insert the new user
        $stmt = $con->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $password);
        
        if ($stmt->execute()) {
            // Signup successful
            echo "<script>alert('Signup successful! Please log in.'); window.location.href = 'login.php';</script>";
        } else {
            // Signup failed
            echo "Error: " . $stmt->error;
        }
        
        // Close statement
        $stmt->close();
    }
    
    // Close check statement
    $checkStmt->close();
}

// Close connection
$con->close();
?>
