<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://unpkg.com/scrollreveal"></script>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <link rel="stylesheet" href="./css/styles.css" />
    <title>Login - Exclusive E-Commerce Website</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
        }
    </style>
</head>
<body>
    <div class="top_nav">
        <div class="container top_nav_container">
            <div class="top_nav_wrapper">
                <p class="tap_nav_p">Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%!</p>
                <a href="#" class="top_nav_link">SHOP NOW</a>
            </div>
        </div>
    </div>
    <nav class="nav">
        <div class="container nav_container">
            <a href="#" class="nav_logo">EXCLUSIVE</a>
            <ul class="nav_list">
                <li class="nav_item"><a href="/" class="nav_link">Home</a></li>
                <li class="nav_item"><a href="#" class="nav_link">About</a></li>
                <li class="nav_item"><a href="#" class="nav_link">Contact</a></li>
                <li class="nav_item"><a href="./sign-up.php" class="nav_link">Sign up</a></li>
            </ul>
            <div class="nav_items">
                <form action="#" class="nav_form">
                    <input type="text" class="nav_input" placeholder="search here...." />
                    <img src="./image/search.png" alt="" class="nav_search" />
                </form>
                <img src="./image/heart.png" alt="" class="nav_heart" />
                <a href="/cart.html">
                    <img src="./image/cart.png" alt="" class="nav_cart" />
                </a>
            </div>
            <span class="hamburger">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                </svg>
            </span>
        </div>
    </nav>
    <nav class="mobile_nav mobile_nav_hide">
        <ul class="mobile_nav_list">
            <li class="mobile_nav_item"><a href="/" class="mobile_nav_link">Home</a></li>
            <li class="mobile_nav_item"><a href="#" class="mobile_nav_link">About</a></li>
            <li class="mobile_nav_item"><a href="#" class="mobile_nav_link">Contact</a></li>
            <li class="mobile_nav_item"><a href="./sign-up.php" class="mobile_nav_link">Sign Up</a></li>
            <li class="mobile_nav_item"><a href="/cart.html" class="mobile_nav_link">Cart</a></li>
        </ul>
    </nav>

    <section class="section">
        <div class="auth_container">
            <div class="auth_img">
                <img src="./image/auth-image.png" alt="Authentication Image" class="auth_image" />
            </div>
            <div class="auth_content">
                <form action="proccess.php" method="post" class="auth_form">
                    <h2 class="form_title">Login to your account</h2>
                    <p class="auth_p">Enter your details below</p>
                    <div class="form_group">
                        <input type="text" id="username" name="username" placeholder="Username" class="form_input" required />
                    </div>
                    <div class="form_group form_pass">
                        <input type="password" id="password" name="password" placeholder="Password" class="form_input" required />
                    </div>
                    <div class="form_group">
                        <button type="submit" class="form_btn" onclick="checkAdmin()">Login</button>
                    </div>
                    <div class="form_group">
                        <span>Don't have an account? <a href="sign-up.php" class="form_auth_link">Register</a></span>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <footer class="footer">
      <div class="container footer_container">
        <div class="footer_item">
          <a href="#" class="footer_logo">Exclusive</a>
          <div class="footer_p">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            Exercitationem fuga harum voluptate?
          </div>
        </div>
        <div class="footer_item">
          <h3 class="footer_item_titl">Support</h3>
          <ul class="footer_list">
            <li class="li footer_list_item">Akkar, Lebanon</li>
            <li class="li footer_list_item">soulaymansajed@gmail.com</li>
            <li class="li footer_list_item">+961 71 656 222</li>
            <li class="li footer_list_item"></li>
          </ul>
        </div>
        <div class="footer_item">
          <h3 class="footer_item_titl">Support</h3>
          <ul class="footer_list">
            <li class="li footer_list_item">Account</li>
            <li class="li footer_list_item">Login / Register</li>
            <li class="li footer_list_item">Cart</li>
            <li class="li footer_list_item">Shop</li>
          </ul>
        </div>
        <div class="footer_item">
          <h3 class="footer_item_titl">Support</h3>
          <ul class="footer_list">
            <li class="li footer_list_item">Privacy policy</li>
            <li class="li footer_list_item">Terms of use</li>
            <li class="li footer_list_item">FAQ's</li>
            <li class="li footer_list_item">Contact</li>
          </ul>
        </div>
      </div>
      <div class="footer_bottom">
        <div class="container footer_bottom_container">
          <p class="footer_copy">
            Copyright Exclusive 2023. All right reserved
          </p>
        </div>
      </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="./js/app.js"></script>
    <script>
 function checkAdmin() {
        var email = document.getElementById('username').value;
        var password = document.getElementById('password').value;

        if (email === 'admin@gmail.com') {
            if (password === 'admin12') {
                window.location.href = 'Admin.php';
            } else {
                alert("Authorized Access only!");
            }
        }
    }
    </script>
  </body>
  <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
    }
  </style>
</html>
