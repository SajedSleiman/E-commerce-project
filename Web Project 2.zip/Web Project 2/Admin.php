<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home - Exclusive E-Commerce Website</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
  <link rel="stylesheet" href="./css/styles.css">
  <style>
    table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
      padding: 8px;
      text-align: center;
    }

    
    .product-image {
      max-width: 100px; 
      max-height: 100px; 
    }

    
    .delete-button {
      background-color: #dc3545;
      color: white;
      border: none;
      padding: 5px 10px;
      cursor: pointer;
      border-radius: 5px;
    }
  </style>
</head>
<body>
    
  <div class="top_nav">
    <div class="container top_nav_container">
      <div class="top_nav_wrapper">
        <p class="tap_nav_p">
          Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%!
        </p>
        <a href="#" class="top_nav_link">SHOP NOW</a>
      </div>
    </div>
  </div>
  <nav class="nav">
    <div class="container nav_container">
      <a href="#" class="nav_logo">EXCLUSIVE</a>
      <ul class="nav_list">
        <li class="nav_item"><a href="/" class="nav_link">Home</a></li>
        <li class="nav_item"><a href="#" class="nav_link">About</a></li>
        <li class="nav_item"><a href="#" class="nav_link">Contact</a></li>
        <li class="nav_item">
          <a href="sign-up.php" class="nav_link">Sign up</a>
        </li>
      </ul>
      <div class="nav_items">
        <form action="#" class="nav_form">
          <input
            type="text"
            class="nav_input"
            placeholder="search here...." />
          <img src="./image/search.png" alt="" class="nav_search" />
        </form>
        <img src="./image/heart.png" alt="" class="nav_heart" />
        <a href="/cart.html">
          <img src="./image/cart.png" alt="" class="nav_cart" />
        </a>
      </div>
      <span class="hamburger">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          stroke-width="1.5"
          stroke="currentColor"
          class="w-6 h-6">
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
        </svg>
      </span>
    </div>
  </nav>
  <nav class="mobile_nav mobile_nav_hide">
    <ul class="mobile_nav_list">
      <li class="mobile_nav_item">
        <a href="/" class="mobile_nav_link">Home</a>
      </li>
      <li class="mobile_nav_item">
        <a href="#" class="mobile_nav_link">About</a>
      </li>
      <li class="mobile_nav_item">
        <a href="#" class="mobile_nav_link">Contact</a>
      </li>
      <li class="mobile_nav_item">
        <a href="/sign-up.html" class="mobile_nav_link">Sign Up</a>
      </li>
      <li class="mobile_nav_item">
        <a href="/cart.html" class="mobile_nav_link">Cart</a>
      </li>
    </ul>
  </nav>

  <div class="container">
    <h1>Product Management</h1>
    <form id="productForm" class="row g-3">
      <div class="col-md-4">
        <label for="pic" class="form-label">Product Picture:</label>
        <input type="file" class="form-control" id="pic">
      </div>
      <div class="col-md-4">
        <label for="price" class="form-label">Product Price:</label>
        <input type="number" class="form-control" id="price">
      </div>
      <div class="col-md-4">
        <label for="name" class="form-label">Product Name:</label>
        <input type="text" class="form-control" id="name">
      </div><br><br>
      <div class="col-10">
        <button type="button" class="btn btn-primary" onclick="addProduct()">Add Product</button>
      </div>
    </form>

    <table id="table" class="table table-hover mt-4">
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Price</th>
          <th>Photo</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  </div>

  <footer class="footer">
    <div class="container footer_container">
      <div class="footer_item">
        <a href="#" class="footer_logo">Exclusive</a>
        <div class="footer_p">
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Exercitationem fuga harum voluptate?
        </div>
      </div>
      <div class="footer_item">
        <h3 class="footer_item_titl">Support</h3>
        <ul class="footer_list">
          <li class="li footer_list_item">Stockholm, Sweden</li>
          <li class="li footer_list_item">email@gmail.com</li>
          <li class="li footer_list_item">+46 123 456 78</li>
          <li class="li footer_list_item">+46 72 345 67</li>
        </ul>
      </div>
      <div class="footer_item">
        <h3 class="footer_item_titl">Support</h3>
        <ul class="footer_list">
          <li class="li footer_list_item">Account</li>
          <li class="li footer_list_item">Login / Register</li>
          <li class="li footer_list_item">Cart</li>
          <li class="li footer_list_item">Shop</li>
        </ul>
      </div>
      <div class="footer_item">
        <h3 class="footer_item_titl">Support</h3>
        <ul class="footer_list">
          <li class="li footer_list_item">Privacy policy</li>
          <li class="li footer_list_item">Terms of use</li>
          <li class="li footer_list_item">FAQ's</li>
          <li class="li footer_list_item">Contact</li>
        </ul>
      </div>
    </div>
    <div class="footer_bottom">
      <div class="container footer_bottom_container">
        <p class="footer_copy">
          Copyright Exclusive 2023. All right reserved
        </p>
      </div>
    </div>
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
  <script src="./js/app.js"></script>
</body>
</html>